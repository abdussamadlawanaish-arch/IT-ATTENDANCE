import {
  router,
  json,
  error,
  requireAuth,
  requireAdminEmailAllowlist,
  db,
} from '@appdeploy/sdk';

const ADMIN_EMAILS = ['ahhmadaliyou2000@gmail.com'];
const adminOnly = [requireAuth(), requireAdminEmailAllowlist(ADMIN_EMAILS)];
const staffTable = 'staff_profiles';
const attendanceTable = 'attendance_records';
const qrTable = 'qr_sessions';
const settingsTable = 'attendance_settings';
const defaultSettings = {
  checkInStart: '07:30',
  resumption: '08:00',
  closing: '16:00',
  graceMinutes: 0,
};

function lagosDate() {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Africa/Lagos',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(new Date());
  const values = Object.fromEntries(parts.map(part => [part.type, part.value]));
  return values.year + '-' + values.month + '-' + values.day;
}
function lagosTime() {
  return new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Africa/Lagos',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).format(new Date());
}
function lagosIso() {
  return new Date().toISOString();
}
function isAdminEmail(email?: string) {
  return Boolean(email && ADMIN_EMAILS.includes(email.toLowerCase()));
}
async function listStaff() {
  const result = await db.list(staffTable, { limit: 500 });
  return result.items;
}
async function listAttendance() {
  const result = await db.list(attendanceTable, { limit: 500 });
  return result.items;
}
async function getSettings() {
  const [saved] = await db.get(settingsTable, ['global']);
  return saved || defaultSettings;
}
function safeText(value: unknown, max = 180) {
  return typeof value === 'string' ? value.trim().slice(0, max) : '';
}
function jsonDateId(date: string) {
  return date.replace(/-/g, '');
}
async function sha256(value: string) {
  const bytes = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(digest))
    .map(value => value.toString(16).padStart(2, '0'))
    .join('');
}
function makeToken() {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return Array.from(bytes)
    .map(value => value.toString(16).padStart(2, '0'))
    .join('');
}
async function ensureQrSession() {
  const date = lagosDate();
  const id = jsonDateId(date);
  const now = Date.now();
  const [existing] = await db.get(qrTable, [id], { consistent: true });
  const token = makeToken();
  const expiresAt = now + 60000;
  const record = {
    date,
    tokenHash: await sha256(token),
    expiresAt,
    updatedAt: lagosIso(),
  };
  if (existing) {
    const [updated] = await db.update(qrTable, [{ id, record }]);
    if (!updated) throw new Error('Could not rotate the QR session.');
  } else {
    const [created] = await db.tx.add(qrTable, [{ id, ...record }]);
    if (!created) {
      const [raced] = await db.get(qrTable, [id], { consistent: true });
      if (!raced) throw new Error('Could not create the QR session. Please refresh.');
      return ensureQrSession();
    }
  }
  return { token, expiresAt, date };
}
async function findStaffByEmail(email: string) {
  const all = await listStaff();
  return (
    all.find(
      person =>
        String(person.email || '').toLowerCase() === email.toLowerCase() &&
        person.status === 'active'
    ) || null
  );
}
function attendanceStatus(checkIn: string, settings: any) {
  const [hour, minute] = checkIn.split(':').map(Number);
  const [resHour, resMinute] = String(settings.resumption || '08:00')
    .split(':')
    .map(Number);
  const actual = hour * 60 + minute;
  const threshold =
    resHour * 60 + resMinute + Number(settings.graceMinutes || 0);
  return actual > threshold ? 'LATE' : 'PRESENT';
}
function authEmail(ctx: any) {
  return String(ctx.user?.email || '').toLowerCase();
}

export const handler = router({
  'GET /api/_healthcheck': [
    async () => json({ message: 'FMC IT Unit Attendance API ready' }),
  ],

  'GET /api/bootstrap': [
    requireAuth(),
    async ctx => {
      const email = authEmail(ctx);
      const admin = isAdminEmail(email);
      const today = lagosDate();
      const settings = await getSettings();
      if (admin) {
        const [staff, attendance] = await Promise.all([
          listStaff(),
          listAttendance(),
        ]);
        return json({
          isAdmin: true,
          profile: null,
          staff,
          attendance,
          settings,
          today,
        });
      }
      if (!email)
        return error(
          'Your sign-in account does not provide an email address.',
          403
        );
      const [staff, attendance] = await Promise.all([
        findStaffByEmail(email),
        listAttendance(),
      ]);
      if (!staff)
        return error(
          'Your email is not registered as an active IT Unit staff member. Contact the system administrator.',
          403
        );
      const ownAttendance = attendance.filter(
        record => String(record.email || '').toLowerCase() === email
      );
      return json({
        isAdmin: false,
        profile: staff,
        staff: [],
        attendance: ownAttendance,
        settings,
        today,
      });
    },
  ],

  'POST /api/admin/staff': [
    ...adminOnly,
    async ctx => {
      const body = (ctx.body || {}) as Record<string, unknown>;
      const fullName = safeText(body.fullName);
      const staffId = safeText(body.staffId, 80);
      const email = safeText(body.email, 180).toLowerCase();
      if (!fullName || !staffId || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
        return error(
          'Full name, staff ID and a valid email address are required.',
          400
        );
      const all = await listStaff();
      if (
        all.some(
          person =>
            String(person.staffId).toLowerCase() === staffId.toLowerCase()
        )
      )
        return error('That staff ID is already registered.', 409);
      if (all.some(person => String(person.email).toLowerCase() === email))
        return error('That email address is already registered.', 409);
      const record = {
        fullName,
        staffId,
        email,
        phone: safeText(body.phone, 40),
        department: safeText(body.department, 120) || 'Information Technology',
        designation: safeText(body.designation, 120),
        status: 'active',
        createdAt: lagosIso(),
      };
      const [id] = await db.add(staffTable, [record]);
      if (!id) return error('Staff record could not be saved.', 500);
      return json({ id, ...record }, 201);
    },
  ],

  'PUT /api/admin/staff/:id': [
    ...adminOnly,
    async ctx => {
      const id = ctx.params.id;
      const [existing] = await db.get(staffTable, [id]);
      if (!existing) return error('Staff record not found.', 404);
      const body = (ctx.body || {}) as Record<string, unknown>;
      const email = safeText(body.email, 180).toLowerCase();
      if (
        !safeText(body.fullName) ||
        !safeText(body.staffId) ||
        !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
      )
        return error('Full name, staff ID and valid email are required.', 400);
      const all = await listStaff();
      if (
        all.some(
          person =>
            person.id !== id &&
            String(person.staffId).toLowerCase() ===
              safeText(body.staffId).toLowerCase()
        )
      )
        return error('That staff ID is already in use.', 409);
      if (
        all.some(
          person =>
            person.id !== id && String(person.email).toLowerCase() === email
        )
      )        return error('That email address is already in use.', 409);
      const record = {
        ...existing,
        fullName: safeText(body.fullName),
        staffId: safeText(body.staffId, 80),
        email,
        phone: safeText(body.phone, 40),
        department: safeText(body.department, 120),
        designation: safeText(body.designation, 120),
      };
      const [updated] = await db.update(staffTable, [{ id, record }]);
      if (!updated) return error('Staff record could not be updated.', 500);
      return json({ id, ...record });
    },
  ],

  'DELETE /api/admin/staff/:id': [
    ...adminOnly,
    async ctx => {
      const id = ctx.params.id;
      const [existing] = await db.get(staffTable, [id]);
      if (!existing) return error('Staff record not found.', 404);
      const [updated] = await db.update(staffTable, [
        {
          id,
          record: {
            ...existing,
            status: 'inactive',
            deactivatedAt: lagosIso(),
          },
        },
      ]);
      if (!updated)
        return error('Staff account could not be deactivated.', 500);
      return json({ ok: true });
    },
  ],

  'GET /api/admin/qr': [
    ...adminOnly,
    async () => {
      try {
        return json(await ensureQrSession());
      } catch (err: any) {
        return error(err?.message || 'QR generation failed.', 500);
      }
    },
  ],

  'POST /api/attendance/checkin': [
    requireAuth(),
    async ctx => {
      const email = authEmail(ctx);
      if (!email)
        return error(
          'Your sign-in account must provide an email address.',
          403
        );
      if (isAdminEmail(email))
        return error(
          'The Super Admin account is for system administration. Register a staff profile to record staff attendance.',
          403
        );
      const staff = await findStaffByEmail(email);
      if (!staff)
        return error(
          'Your email is not registered as an active IT Unit staff member.',
          403
        );
      const body = (ctx.body || {}) as Record<string, unknown>;
      const token = safeText(body.token, 200);
      if (!token) return error('A QR token is required.', 400);
      const date = lagosDate();
      const id = jsonDateId(date);
      const [session] = await db.get(qrTable, [id], { consistent: true });
      if (!session || session.expiresAt <= Date.now())
        return error(
          'This QR code has expired. Scan the current code displayed at the entrance.',
          410
        );
      const suppliedHash = await sha256(token);
      if (suppliedHash !== String(session.tokenHash || ''))
        return error(
          'Invalid or expired QR code. Please scan the latest entrance display.',
          403
        );
      const now = new Date();
      const checkIn = lagosTime();
      const recordId =
        id +
        '_' +
        (await sha256(String(staff.id)).then(value => value.slice(0, 24)));
      const [existing] = await db.get(attendanceTable, [recordId], {
        consistent: true,
      });
      if (existing)
        return error(
          'Your attendance has already been recorded for today at ' +
            existing.checkIn +
            '.',
          409
        );
      const settings = await getSettings();
      if (checkIn < String(settings.checkInStart || '07:30'))
        return error('Attendance check-in has not opened yet.', 403);
      if (checkIn > String(settings.closing || '16:00'))
        return error(
          'The attendance check-in window is closed for today.',
          403
        );
      const record = {
        staffRecordId: staff.id,
        staffName: staff.fullName,
        staffId: staff.staffId,
        email,
        date,
        checkIn: now.toISOString(),
        localCheckIn: checkIn,
        status: attendanceStatus(checkIn, settings),
        qrSessionId: id,
        createdAt: now.toISOString(),
      };
      const [created] = await db.tx.add(attendanceTable, [
        { id: recordId, ...record },
      ]);
      if (!created)
        return error(
          'Attendance has already been recorded or could not be saved. Contact your supervisor if this appears incorrect.',
          409
        );
      return json({
        ok: true,
        checkIn: record.checkIn,
        status: record.status,
        staffName: staff.fullName,
      });
    },
  ],

  'POST /api/attendance/checkout': [
    requireAuth(),
    async ctx => {
      const email = authEmail(ctx);
      if (!email) return error('Your sign-in account must provide an email address.', 403);
      if (isAdminEmail(email)) return error('The Super Admin account cannot record staff attendance.', 403);
      const staff = await findStaffByEmail(email);
      if (!staff) return error('Your email is not registered as an active IT Unit staff member.', 403);
      const body = (ctx.body || {}) as Record<string, unknown>;
      const token = safeText(body.token, 200);
      if (!token) return error('A QR token is required.', 400);
      const date = lagosDate();
      const sessionId = jsonDateId(date);
      const [session] = await db.get(qrTable, [sessionId], { consistent: true });
      if (!session || session.expiresAt <= Date.now()) return error('This QR code has expired. Scan the current code displayed at the entrance.', 410);
      if ((await sha256(token)) !== String(session.tokenHash || '')) return error('Invalid or expired QR code. Please scan the latest entrance display.', 403);
      const recordId = sessionId + '_' + (await sha256(String(staff.id)).then(value => value.slice(0, 24)));
      const [existing] = await db.get(attendanceTable, [recordId], { consistent: true });
      if (!existing) return error('You must check in before you can check out.', 409);
      if (existing.checkOut) return error('Your check-out has already been recorded today at ' + (existing.localCheckOut || existing.checkOut) + '.', 409);
      const now = new Date();
      const localCheckOut = lagosTime();
      const totalHours = Math.max(0, Number(((now.getTime() - new Date(existing.checkIn).getTime()) / 3600000).toFixed(2)));
      const [updated] = await db.tx.update(attendanceTable, [{
        id: recordId,
        record: { checkOut: now.toISOString(), localCheckOut, totalHours, updatedAt: now.toISOString() },
        if: { checkOut: undefined },
      }], { patch: true });
      if (!updated) return error('Your check-out may already have been recorded. Refresh your attendance history.', 409);
      return json({ ok: true, checkOut: now.toISOString(), localCheckOut, totalHours, staffName: staff.fullName });
    },
  ],

  'PUT /api/admin/settings': [
    ...adminOnly,
    async ctx => {
      const body = (ctx.body || {}) as Record<string, unknown>;
      const checkInStart = safeText(body.checkInStart, 5);
      const resumption = safeText(body.resumption, 5);
      const closing = safeText(body.closing, 5);
      const validTime = (value: string) =>
        /^([01]\d|2[0-3]):[0-5]\d$/.test(value);
      const graceMinutes = Number(body.graceMinutes);
      if (
        ![checkInStart, resumption, closing].every(validTime) ||
        !Number.isInteger(graceMinutes) ||
        graceMinutes < 0 ||
        graceMinutes > 120
      )
        return error(
          'Enter valid times and a grace period between 0 and 120 minutes.',
          400
        );
      if (checkInStart >= closing || resumption >= closing)
        return error(
          'Closing time must be later than check-in and resumption times.',
          400
        );
      const record = { checkInStart, resumption, closing, graceMinutes };
      const [existing] = await db.get(settingsTable, ['global']);
      if (existing) {
        const [updated] = await db.update(settingsTable, [
          { id: 'global', record },
        ]);
        if (!updated) return error('Settings could not be saved.', 500);
      } else {
        const [created] = await db.tx.add(settingsTable, [
          { id: 'global', ...record },
        ]);
        if (!created) return error('Settings could not be created.', 500);
      }
      return json(record);
    },
  ],
});
